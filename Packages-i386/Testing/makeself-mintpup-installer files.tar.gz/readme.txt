http://stephanepeter.com/makeself/

makeself.sh --notemp /mnt/sda1/casper/mintpup-frugall-installer/debdog-appimage test-installer-bzip2 "mintpup frugal installer" ./AppRun

makeself.sh --notemp --xz /mnt/sda1/casper/mintpup-frugall-installer/debdog-appimage test-installer-bzip2 "mintpup frugal installer" ./AppRun
makeself.sh --nomd5 --nocrc --nox11 /live/image/casper/portable-mintpup-installer install-mintpup-xz "MintPup frugal installer" ./start-installer



